package com.kbhkn.designpattern.iteratorpattern;

/**
 * Created by Kbhkn on 10.11.2017.
 */
public interface ChannelIterator {
    public boolean hasNext();
    public Channel next();
}
