package com.kbhkn.designpattern.iteratorpattern;

/**
 * Created by Kbhkn on 10.11.2017.
 */
public enum ChannelTypeEnum {
    TURKISH, ENGLISH, FRENCH, ALL;
}
