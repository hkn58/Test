package com.kbhkn.designpattern.iteratorpattern;

/**
 * Created by Kbhkn on 10.11.2017.
 */
public interface ChannelCollection {
    public void addChannel(Channel c);
    public void removeChannel(Channel c);
    public ChannelIterator iterator(ChannelTypeEnum type);
}
