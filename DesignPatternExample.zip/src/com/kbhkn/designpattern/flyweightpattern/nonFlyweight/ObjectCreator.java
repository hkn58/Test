package com.kbhkn.designpattern.flyweightpattern.nonFlyweight;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Kbhkn on 9.11.2017.
 */
public class ObjectCreator {
    public List createObjects() {
        List businessObjects = new ArrayList();
        for (int i = 0; i < 500000; i++) {
            if (isGolden(i)) {
                Key goldenKey = new Key("Golden", true);
                BusinessObject bo = new BusinessObject(goldenKey, "Name : " + i, i);
                businessObjects.add(bo);
            } else if (isSilver(i)) {
                Key silverKey = new Key("Silver", true);
                BusinessObject bo = new BusinessObject(silverKey, "Name : " + i, i);
                businessObjects.add(bo);
            } else if (isBronze(i)) {
                Key bronzeKey = new Key("Bronze", true);
                BusinessObject bo = new BusinessObject(bronzeKey, "Name : " + i, i);
                businessObjects.add(bo);
            } else {
                Key emptyKey = new Key("", false);
                BusinessObject bo = new BusinessObject(emptyKey, "Name : " + i, i);
                businessObjects.add(bo);
            }
        }
        return businessObjects;
    }

    private boolean isBronze(int i) {
        return (i % 7) == 0;
    }

    private boolean isGolden(int i) {
        return (i % 3) == 0;
    }

    private boolean isSilver(int i) {
        return (i % 5) == 0;
    }
}
