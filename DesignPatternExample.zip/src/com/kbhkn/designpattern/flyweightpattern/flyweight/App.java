package com.kbhkn.designpattern.flyweightpattern.flyweight;

import java.util.List;

/**
 * Created by Kbhkn on 9.11.2017.
 */
public class App {
    public static void main(String[] args) throws InterruptedException {
        ObjectCreator objectCreator = new ObjectCreator();
        List businessObjects = objectCreator.createObjects();

        Thread.sleep(100000);
    }
}
