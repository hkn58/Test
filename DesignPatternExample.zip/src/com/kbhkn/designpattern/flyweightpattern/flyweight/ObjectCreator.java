package com.kbhkn.designpattern.flyweightpattern.flyweight;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Kbhkn on 9.11.2017.
 */
public class ObjectCreator {
    public List createObjects() {
        List businessObjects = new ArrayList();
        for (int i = 0; i < 500000; i++) {
            BusinessObject bo = new BusinessObject(KeyFactory.create(i), "Name : " + i, i);
            businessObjects.add(bo);
        }
        return businessObjects;
    }
}
