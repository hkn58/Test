package com.kbhkn.designpattern.adapterpattern;

/**
 * Created by Kbhkn on 9.11.2017.
 */
public class StartGame {
    public static void main(String[] args) {
        Robot r = new Robot();
        r.reactToHuman("Ben");
        r.walkForward();
        r.smashWithHands();

        IEnemy tank1 = new Tank();
        IEnemy robotAdapter = new RobotAdapter(r);

        System.out.println("Tank1...");
        tank1.assignDriver("Tank1");
        tank1.driveForward();
        tank1.fireWeapon();

        System.out.println("Robot...");
        robotAdapter.assignDriver("Mark");
        robotAdapter.driveForward();
        robotAdapter.fireWeapon();
    }
}
