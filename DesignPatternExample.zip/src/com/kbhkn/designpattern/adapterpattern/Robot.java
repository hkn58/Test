package com.kbhkn.designpattern.adapterpattern;

import java.util.Random;

/**
 * Created by Kbhkn on 9.11.2017.
 */
public class Robot {
    Random r = new Random();

    public void smashWithHands() {
        System.out.printf("Robot causes %d damage with it's hands\n", (r.nextInt(10) + 1));
    }

    public void walkForward() {
        System.out.printf("Robot walks forward %d spaces\n", (r.nextInt(4) + 1));
    }

    public void reactToHuman(String driverName) {
        System.out.printf("Robot tramps on %s\n", driverName);
    }
}
