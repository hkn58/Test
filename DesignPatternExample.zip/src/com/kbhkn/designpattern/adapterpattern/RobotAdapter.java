package com.kbhkn.designpattern.adapterpattern;

/**
 * Created by Kbhkn on 9.11.2017.
 */
public class RobotAdapter implements IEnemy {
    public Robot enemyRobot;

    public RobotAdapter(Robot robot) {
        this.enemyRobot = robot;
    }

    @Override
    public void fireWeapon() {
        enemyRobot.smashWithHands();
    }

    @Override
    public void driveForward() {
        enemyRobot.walkForward();
    }

    @Override
    public void assignDriver(String name) {
        enemyRobot.reactToHuman(name);
    }
}
