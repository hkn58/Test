package com.kbhkn.designpattern.adapterpattern;

/**
 * Created by Kbhkn on 9.11.2017.
 */
public interface IEnemy {
    public void fireWeapon();

    public void driveForward();

    public void assignDriver(String name);

}
