package com.kbhkn.designpattern.adapterpattern;

import java.util.Random;

/**
 * Created by Kbhkn on 9.11.2017.
 */
public class Tank implements IEnemy {
    Random r = new Random();

    @Override
    public void fireWeapon() {
        System.out.printf("Tank does %d damage\n", (r.nextInt(20) + 1));
    }

    @Override
    public void driveForward() {
        System.out.printf("Tank moves: %d spaces\n", (r.nextInt(10) + 1));
    }

    @Override
    public void assignDriver(String name) {
        System.out.printf("%s is driving the Tank\n", name);
    }
}
